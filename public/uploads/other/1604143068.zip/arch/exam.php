<?php
// header ('Content-Type: image/svg+xml');
// header ('Content-Disposition: filename=example.svg');
    $str="<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<svg version=\"1.1\"

     xml:space=\"preserve\"
     xmlns=\"http://www.w3.org/2000/svg\" 
     xmlns:xlink=\"http://www.w3.org/1999/xlink\"
    style=\"shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd\"
     width=\"210mm\" height=\"297mm\" viewBox=\"0 0 210 297\">
          <g fill=\"none\" stroke=\"black\">\n";
// Calculate the coordinate of the Bezier curve at $t = 0..1
function Bezier_eval($p1,$p2,$p3,$t) {
  $q1  = array((1-$t) * $p1[0] + $t * $p2[0],(1-$t) * $p1[1] + $t * $p2[1]);
  $q2  = array((1-$t) * $p2[0] + $t * $p3[0],(1-$t) * $p2[1] + $t * $p3[1]);
  $r1  = array((1-$t) * $q1[0] + $t * $q2[0],(1-$t) * $q1[1] + $t * $q2[1]);
  return $r1;
}

// Calculate the squared distance between two points
function Point_distance2($p1,$p2) {
  $dx = $p2[0] - $p1[0];
  $dy = $p2[1] - $p1[1];
  return $dx * $dx + $dy * $dy;
}

// Convert the curve to a polyline
function Bezier_convert($p1,$p2,$p3,$tolerance) {
  $t1 = 0.0;
  $prev = $p1;
  $t2 = 0.1;
  $tol2 = $tolerance * $tolerance;
  $result []= $prev[0];
  $result []= $prev[1];
  while ($t1 < 1.0) {
      if ($t2 > 1.0) {
          $t2 = 1.0;
      }
      $next = Bezier_eval($p1,$p2,$p3,$t2);
      $dist = Point_distance2($prev,$next);
      while ($dist > $tol2) {
          // Halve the distance until small enough
          $t2 = $t1 + ($t2 - $t1) * 0.5;
          $next = Bezier_eval($p1,$p2,$p3,$t2);
          $dist = Point_distance2($prev,$next);
      }
      // the image*polygon functions expect a flattened array of coordiantes
      $result []= $next[0];
      $result []= $next[1];
      $t1 = $t2;
      $prev = $next;
      $t2 = $t1 + 0.1;
  }
  return $result;
}

// Get crossing point a Bezier curve and Line
function Crossing_Bezier_Line($polygon,$p1,$p2) {
  for($i=0; $i < count($polygon)/2; $i++){
      $c_x = $polygon[2*$i];
      $c_y = $polygon[2*$i+1];
      $distance = 100000;
      if($p2[0] == $p1[0] && $p2[1] == $p1[1]) return false;
      if($p2[0] == $p1[0] ) $distance = abs($c_x - $p1[0]);
      else if($p2[1] == $p1[1]) $distance = abs($c_y - $p1[1]);
      else $distance = abs(($c_x - $p1[0]) / ($p2[0] - $p1[0])-($c_y - $p1[1]) / ($p2[1] - $p1[1]));
      if ($distance < 0.01){
          return array($c_x, $c_y);
          break;      
      }

  }
  return false;
  
}
function  midpoint($x1,$y1,$x2,$y2)
  {
      $xf1=(($x1+$x2)/2);
      $yf1=(($y1+$y2)/2);
       $xf1=round ($xf1,3);
       $yf1=round ($yf1,3);
      return array($xf1,$yf1);
  }
  
  function  length_segment($x1,$y1,$x2,$y2)
  {
    $L=round (sqrt(pow(($x2-$x1),2) + pow(($y2-$y1),2)),3);
  	return $L;
  }

function  perpendicular($x1,$y1,$x2,$y2,$D)
  {

    if ($y1==$y2) {$xf1=$x1;$yf1=$y1+$D;$xf2=$x2;$yf2=$y2+$D;} else{

      // A$x1,$y1  B$x2,$y2
      $x_tmp=$x1+($y2-$y1);
   	  $y_tmp=$y1+($x1-$x2);

      //$D
	  $tgA=($y_tmp-$y1)/($x_tmp-$x1);
      $A=atan($tgA);
      $Dx=($D)*cos($A);
      $Dy=($D)*sin($A);
      $xf1=$x1+$Dx;
      $yf1=$y1+$Dy;
      }

       $xf1=round ($xf1,3);
       $yf1=round ($yf1,3);
      return array($xf1,$yf1);
  }


$mylinex1=$_POST['mylinex1'];
$myliney1=$_POST['myliney1'];
$mylinex2=$_POST['mylinex2'];
$myliney2=$_POST['myliney2'];

// Input new line info
$plx=$_POST['plx'];
$ply=$_POST['ply'];
$length=$_POST['length'];

//Calculate new line next position value
$scale_fit = $length/sqrt(($myliney2-$myliney1)*($myliney2-$myliney1) + ($mylinex2-$mylinex1)*($mylinex2-$mylinex1));
$new_x2 = $plx + ($mylinex2-$mylinex1)*$scale_fit;
$new_y2 = $ply + ($myliney2-$myliney1)*$scale_fit;


$line1x1=$_POST['line1x1'];
$line1y1=$_POST['line1y1'];
$line1x2=$_POST['line1x2'];
$line1y2=$_POST['line1y2'];

$line2x1=$_POST['line2x1'];
$line2y1=$_POST['line2y1'];
$line2x2=$_POST['line2x2'];
$line2y2=$_POST['line2y2'];

$x1=$_POST['x1'];
$y1=$_POST['y1'];

$x2=$_POST['x2'];
$y2=$_POST['y2'];

$F_Array=midpoint($x1,$y1,$x2,$y2); 
$cx1=$F_Array[0];
$cy1=$F_Array[1];

$L=length_segment($x1,$y1,$x2,$y2)/2; 

$F_Array=perpendicular($cx1,$cy1,$x2,$y2,-$L); 
$x3=$F_Array[0];
$y3=$F_Array[1];

// Get Bezier curve array.
$polygon = Bezier_convert(array($x1,$y1),array($x3,$y3),array($x2,$y2),1.0);

// Get crossing point beizer curve and line1.
$crossing_point1 = Crossing_Bezier_Line($polygon,array($line1x1,$line1y1),array($line1x2,$line1y2));

// Get crossing point beizer curve and line2.
$crossing_point2 = Crossing_Bezier_Line($polygon,array($line2x1,$line2y1),array($line2x2,$line2y2));


//Х Y

 $str.="<text x=\"30\" y=\"30\" font-size=\"5\" fill=\"black\" stroke=\"none\">FUNCTION 1</text>\n";

$str.="<line stroke-width=\"0.4\" x1=\"10\" y1=\"10\" x2=\"400\" y2=\"10\" stroke=\"red\"  stroke-dasharray=\"5,5,5,5\"/>\n";
$str.="<line stroke-width=\"0.4\" x1=\"10\" y1=\"10\" x2=\"10\" y2=\"400\" stroke=\"red\" stroke-dasharray=\"5,5,5,5\"/>\n";

//my line
$str.="<text x=\"$mylinex1\" y=\"$myliney1\" font-size=\"5\" fill=\"black\" stroke=\"none\">My line</text>\n";
$str.="<line stroke-width=\"1\" x1=\"$mylinex1\" y1=\"$myliney1\" x2=\"$mylinex2\" y2=\"$myliney2\" stroke=\"green\"  />\n";

//new line
$str.="<text x=\"$plx\" y=\"$ply\" font-size=\"5\" fill=\"black\" stroke=\"none\">New line</text>\n";
$str.="<line stroke-width=\"1\" x1=\"$plx\" y1=\"$ply\" x2=\"$new_x2\" y2=\"$new_y2\" stroke=\"green\"  />\n";
$str.="<text x=\"$new_x2\" y=\"$new_y2\" font-size=\"5\" fill=\"black\" stroke=\"none\">($new_x2, $new_y2)</text>\n";
$str.="<circle cx=\"$new_x2\" cy=\"$new_y2\" r=\"1\" fill=\"red\" stroke=\"red\"/>\n";


$str.="<text x=\"30\" y=\"100\" font-size=\"5\" fill=\"black\" stroke=\"none\">FUNCTION 2</text>\n";
 
 // line 1
$str.="<text x=\"$line1x1\" y=\"$line1y1\" font-size=\"5\" fill=\"black\" stroke=\"none\">line 1</text>\n";
$str.="<line stroke-width=\"1\" x1=\"$line1x1\" y1=\"$line1y1\" x2=\"$line1x2\" y2=\"$line1y2\" stroke=\"green\"  />\n";

 // line 2
$str.="<text x=\"$line2x1\" y=\"$line2y1\" font-size=\"5\" fill=\"black\" stroke=\"none\">line 2</text>\n";
$str.="<line stroke-width=\"1\" x1=\"$line2x1\" y1=\"$line2y1\" x2=\"$line2x2\" y2=\"$line2y2\" stroke=\"green\"  />\n";

// Curve
$str.="<path stroke=\"green\" stroke-width=\"1\" d=\"M $x1,$y1 Q $x3,$y3 $x2,$y2\"/>\n"; 

// crossing point1
if($crossing_point1!=false){
  $str.="<text x=\"$crossing_point1[0]\" y=\"$crossing_point1[1]\" font-size=\"5\" fill=\"black\" stroke=\"none\">G1</text>\n";
  $str.="<circle cx=\"$crossing_point1[0]\" cy=\"$crossing_point1[1]\" r=\"1\" fill=\"red\" stroke=\"red\"/>\n";
  
}

// crossing point2
if($crossing_point2!=false){
  $str.="<text x=\"$crossing_point2[0]\" y=\"$crossing_point2[1]\" font-size=\"5\" fill=\"black\" stroke=\"none\">G2</text>\n";
  $str.="<circle cx=\"$crossing_point2[0]\" cy=\"$crossing_point2[1]\" r=\"1\" fill=\"red\" stroke=\"red\"/>\n";
  
}

$str.="</g>
</svg>
\n";

echo $str;

?>

